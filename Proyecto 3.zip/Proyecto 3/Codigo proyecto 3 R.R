pacman::p_load(rgdal, rgeos, stars, spatstat, spdep, sf, raster, tidyverse,
               spatialreg, tidyverse, vapour, gstat, MASS, spdep, tmap, mapview,foreign,factoextra,dplyr,e1071,
               caret,paran,fpc)

#Cargamos los datos
data = read.dbf('RM_SII_CBR2.dbf')
geom = st_read('RM_SII_CBR2.shp')

#--------------------Limpieza de datos----------------
#Seleccionamos la comuna de las condes
datos_lascondes = data %>% dplyr::filter(COMUNA == 'LAS CONDES') 
geom_las_condes = geom %>% dplyr::filter(COMUNA == 'LAS CONDES')

#Seleccionamos las columnas para nuestro an�lisis
data_s = datos_lascondes %>% dplyr::select(AVALUO, ANO, ANO_CONSTR, MANZ,CONTRIBUCI,SUP_TERR,ANO_CONSTR,SUP_CONSTR,UF_TRANS,ESTACIONAM,SC_TPRIV,
                                TPR_CBD,TPR_ElGolf,TPR_NvaLCo,TPR_Provi,Casas_UFPr,Depto_UFPr,IMORANCASA,IMORANDPTO,ABC1_12,
                                C2_12,C3_12,D_12,E_12,ABC1_12P,C2_12P,C3_12P,D_12P,E_12P,POB_FLOT,Por_veg_pr,HA_MZ,DEN_MZ,SC_15MIN,
                                Ten_Metro,Ten_MetroC,COLE_5MIN,COLE_10MIN,COLE_10MIN,JARDIN_5M,JARDIN_10M,JARDIN_15M,AV_15_MIN,
                                COMERCIO,EDUCACION,SALUD,SERVICIOS,OFICINA,IMORANCASA,IMORANDPTO)

geom_s = geom_las_condes %>% dplyr::select(AVALUO, ANO, ANO_CONSTR, MANZ,CONTRIBUCI,SUP_TERR,ANO_CONSTR,SUP_CONSTR,UF_TRANS,ESTACIONAM,SC_TPRIV,
                                TPR_CBD,TPR_ElGolf,TPR_NvaLCo,TPR_Provi,Casas_UFPr,Depto_UFPr,IMORANCASA,IMORANDPTO,ABC1_12,
                                C2_12,C3_12,D_12,E_12,ABC1_12P,C2_12P,C3_12P,D_12P,E_12P,POB_FLOT,Por_veg_pr,HA_MZ,DEN_MZ,SC_15MIN,
                                Ten_Metro,Ten_MetroC,COLE_5MIN,COLE_10MIN,COLE_10MIN,JARDIN_5M,JARDIN_10M,JARDIN_15M,AV_15_MIN,
                                COMERCIO,EDUCACION,SALUD,SERVICIOS,OFICINA,IMORANCASA,IMORANDPTO,geometry)


#Reemplazamos los na por la media de su columna
NA2mean = function(x) replace(x, is.na(x),mean(x, na.rm = TRUE))
datos_sin_na = replace(data_s, TRUE, lapply(data_s, NA2mean))
geom_sin_na = replace(geom_s, TRUE, lapply(geom_s, NA2mean))

#Graficamos los datos de las condes
plot(st_geometry(geom_sin_na))



#kmeans = kmeans(datos_sin_na,centers = 3)
#geom_sin_na$cluster_kmeans <- as.factor(kmeans$cluster)

#ggplot(geom_sin_na$cluster_kmeans)+
#  geom_sf(aes(fill = 'red'))

#----------------Hacemos un PCA para determinar cuales son las variables que m�s informaci�n aportan----------------
pca = prcomp(datos_sin_na,scale=T)
summary(pca)

#Calculamos y graficamos la varianza de cada componente
prop_varianza = pca$sdev^2 / sum(pca$sdev^2)
prop_varianza
ggplot(data = data.frame(prop_varianza, pc = 1:46),
       aes(x = pc, y = prop_varianza)) +
  geom_col(width = 0.3) +
  scale_y_continuous(limits = c(0,1)) +
  theme_bw() +
  labs(x = "Componente principal",
       y = "Prop. de varianza explicada")

#Calculamos y graficamos la varianza acumulada
prop_varianza_acum = cumsum(prop_varianza)
prop_varianza_acum
ggplot(data = data.frame(prop_varianza_acum, pc = 1:46),
       aes(x = pc, y = prop_varianza_acum, group = 1)) +
  geom_point() +
  geom_line() +
  theme_bw() +
  labs(x = "Componente principal",
       y = "Prop. varianza explicada acumulada")

#Calculamos los eigenvalues, que nos ayudan a retener las componentes m�s importantes bajo el criterio de
# eigenvalue >= 1
eig.val = get_eigenvalue(pca)
eig.val #de esta tabla concluimos con que las principales 13 componentes sirven


#A continuaci�n vemos que variables son las que m�s peso/informaci�n tienen en cada componente
var = get_pca_var(pca)
a = fviz_contrib(pca, "var", axes=1, xtickslab.rt=90) 
plot(a,main = "Contribuci�n en el porcentaje de varianza para la primea componente")

a = fviz_contrib(pca, "var", axes=2, xtickslab.rt=90) 
plot(a,main = "Contribuci�n en el porcentaje de varianza para la segunda componente")

a = fviz_contrib(pca, "var", axes=3, xtickslab.rt=90) 
plot(a,main = "Contribuci�n en el porcentaje de varianza para la tercera componente")

a = fviz_contrib(pca, "var", axes=4, xtickslab.rt=90) 
plot(a,main = "Contribuci�n en el porcentaje de varianza para la cuarta componente")

a = fviz_contrib(pca, "var", axes=5, xtickslab.rt=90)
plot(a,main = "Contribuci�n en el porcentaje de varianza para la quinta componente")

a = fviz_contrib(pca, "var", axes=11, xtickslab.rt=90)
plot(a,main = "Contribuci�n en el porcentaje de varianza para la onceava componente")

a = fviz_contrib(pca, "var", axes=12, xtickslab.rt=90)
plot(a,main = "Contribuci�n en el porcentaje de varianza para la doceava componente")
#--------------Hacemos otro PCA pero con las componentes seleccionadas------------------
#Como encontramos que 13 componentes cumplian con el eigenvalue >= 1, haremos un nuevo pca con 13 componentes
pca1 = prcomp(datos_sin_na, scale.=TRUE, rank. = 13) 

summary(pca1)
resultados <- pca1$x
str(resultados)

#-------------------KMEANS---------------------
#Hacemos un Kmeans con los resultados del PCA
fviz_nbclust(resultados, kmeans, method = c("silhouette")) #Encontramos el n�mero optimo de clusters (6)
kmeans_optimo = kmeans(resultados,centers = 6)
#kmeans_optimo

geom_sin_na$cluster_kmeans = as.factor(kmeans_optimo$cluster) #agregamos a los datos la columna que asigna cada fila a un cluster
plot(geom_sin_na$cluster_kmeans) #frecuencia de cada cluster

geom_k = geom_sin_na %>% dplyr::select(cluster_kmeans,geometry) 
ggplot(geom_sin_na) +
  geom_sf(aes(color = cluster_kmeans))


datos_sin_na$cluster_kmeans = as.factor(kmeans_optimo$cluster) #agregamos a los datos la columna que asigna cada fila a un cluster


#----------Visualizamos el precio en UF de cada cluster--------------

primer_cluster = datos_sin_na %>% dplyr::filter(cluster_kmeans == 1)
summary(primer_cluster)

segundo_cluster = datos_sin_na %>% dplyr::filter(cluster_kmeans == 2)
summary(segundo_cluster)

tercer_cluster = datos_sin_na %>% dplyr::filter(cluster_kmeans == 3)
summary(tercer_cluster)

cuarto_cluster = datos_sin_na %>% dplyr::filter(cluster_kmeans == 4)
summary(cuarto_cluster)

quinto_cluster = datos_sin_na %>% dplyr::filter(cluster_kmeans == 5)
summary(quinto_cluster)

sexto_cluster = datos_sin_na %>% dplyr::filter(cluster_kmeans == 6)
summary(sexto_cluster)

#-----------Visualizamos los clusters----------------------
#Hacemos un boxplot de las variables que m�s peso tenian en cada componente de los 5 primeros PCA, para compararlos por cluster
boxplot(datos_sin_na$TPR_ElGolf ~ datos_sin_na$cluster_kmeans)
boxplot(datos_sin_na$Depto_UFPr ~ datos_sin_na$cluster_kmeans)
boxplot(datos_sin_na$EDUCACION ~ datos_sin_na$cluster_kmeans)
boxplot(datos_sin_na$CONTRIBUCI ~ datos_sin_na$cluster_kmeans)
boxplot(datos_sin_na$C2_12 ~ datos_sin_na$cluster_kmeans)

#Viendo el boxplot de las UF nos damos cuenta que hay valores que se escapan mucho de los bigotes del box plot, por lo que 
# filtraremos hasta un precio m�ximo de 10.000 uf 
boxplot(datos_sin_na$UF_TRANS ~ datos_sin_na$cluster_kmeans)

datos_sin_na = datos_sin_na %>% dplyr::filter(UF_TRANS < 10000 )
geom_sin_na = geom_sin_na %>% dplyr::filter(UF_TRANS < 10000 )
boxplot(datos_sin_na$UF_TRANS ~ datos_sin_na$cluster_kmeans)


#Graficamos la media de UF por cada cluster
ggplot(geom_sin_na) + 
  geom_bar(aes(cluster_kmeans, UF_TRANS, fill = as.factor(cluster_kmeans)), 
           position = "dodge", stat = "summary", fun.y = "mean")

